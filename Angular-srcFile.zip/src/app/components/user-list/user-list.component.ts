import { UserDetailsComponent } from '../user-details/user-details.component';
import { Observable } from "rxjs";
import { DonorService } from "src/app/donor.service";
import { Donor } from "src/app/donor"
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  donors: Observable<Donor[]>;

  constructor(private donorService: DonorService, private router: Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData() {
    this.donors = this.donorService.getAllUsers();
  }

  deleteEmployee(id: number) {
    this.donorService.deleteUser(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  userDetails(id: number){
    this.router.navigate(['details', id]);
  }

  updateUser(id: number){
    this.router.navigate(['update', id]);
  }



}
