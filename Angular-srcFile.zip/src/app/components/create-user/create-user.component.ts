import { Component, OnInit } from '@angular/core';
import { Donor } from 'src/app/donor';
import { Router } from '@angular/router';
import { DonorService } from 'src/app/donor.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  donor: Donor = new Donor();
  submitted = false;

  constructor(private donorService: DonorService,
    private router: Router) { }

  ngOnInit() {
  }

  newDonor(): void {
    this.submitted = false;
    this.donor = new Donor();
  }

  save() {
    this.donorService
    .addUser(this.donor).subscribe(data => {
      console.log(data)
      this.donor = new Donor();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/donors']);
  }

}
