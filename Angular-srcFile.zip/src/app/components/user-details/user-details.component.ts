import { Component, OnInit } from '@angular/core';
import { UserListComponent } from 'src/app/components/user-list/user-list.component';
import { DonorService } from "src/app/donor.service";
import { Donor } from "src/app/donor"
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  id: number;
  donor: Donor;

  constructor(private route: ActivatedRoute,private router: Router,
    private donorService: DonorService) { }

  ngOnInit() {
    this.donor = new Donor();

    this.id = this.route.snapshot.params['id'];
    
    this.donorService.getUser(this.id)
      .subscribe(data => {
        console.log(data)
        this.donor = data;
      }, error => console.log(error));
  }

  list(){
    this.router.navigate(['donors']);
  }

}
