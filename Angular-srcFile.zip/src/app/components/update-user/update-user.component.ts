import { Component, OnInit } from '@angular/core';
import { Donor } from 'src/app/donor';
import { ActivatedRoute, Router } from '@angular/router';
import { DonorService } from 'src/app/donor.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  id: number;
  donor: Donor;

  constructor(private route: ActivatedRoute,private router: Router,
    private donorService: DonorService) { }

  ngOnInit(): void {
    this.donor = new Donor();

    this.id = this.route.snapshot.params['id'];
    
    this.donorService.getUser(this.id)
      .subscribe(data => {
        console.log(data)
        this.donor = data;
      }, error => console.log(error));
  }

  updateUser() {
    this.donorService.updateUser(this.id, this.donor)
      .subscribe(data => {
        console.log(data);
        this.donor = new Donor();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateUser();    
  }

  gotoList() {
    this.router.navigate(['/donors']);
  }

}
