export class Donor{
    id: number;
    name:String;
    blood_group :String;
    phone: number;
    email:String;
    country:String;
    state:String;
    city:String;
    
}