import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Donor } from './donor';

@Injectable({
  providedIn: 'root'
})
export class DonorService {

  private baseUrl = 'http://localhost:8080/springApplication/donors';

  constructor(private http:HttpClient) { }

  getUser(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  addUser(donor: Donor){
    return this.http.post(`${this.baseUrl}`, Donor);
  }

  updateUser(id: number, value: any){
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteUser(id: number){
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getAllUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
